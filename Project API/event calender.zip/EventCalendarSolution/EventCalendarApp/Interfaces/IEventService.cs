﻿using EventCalendarApp.Models;
using EventCalendarApp.Models.DTOs;

namespace EventCalendarApp.Interfaces
{
    public interface IEventService
    {

        /// <summary>
        /// interface for EventService
        /// </summary>
        /// <returns></returns>
        List<Event> GetEvents();
        Event Add(Event events);
        Event Remove(Event events);
        Event Update(Event events);
    }
}