﻿/*using EventCalendarApp.Models;

namespace EventCalendarApp.Interfaces
{
    public interface INotificationService
    {
        Notification Add(Notification notification);
        public List<Notification> GetNotifications();
        //Notification SendNotification(Notification notification);
        public void SendNotificationEmail(string recipientEmail, string subject, string body);

    }
}
*/