﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using EventCalendarApp.Models.DTOs;
using System.Reflection.Metadata.Ecma335;

namespace EventCalendarApp.Models
{
    public class Event
    {

        /// <summary>
        /// it is a model class for events
        /// </summary>
        public int Id { get; set; }
        public string title { get; set; }
        public string Description { get; set; }
      
        public string StartDateTime { get; set; } 
        public string NotificationDateTime { get; set; }
        public string? Location { get; set; }
        public bool? IsRecurring { get; set; }
        public string Recurring_frequency { get; set; }

       /* public int CategoryId { get; set; }
        [ForeignKey("CategoryId")]
        public Category? Category { get; set; }*/

        public string UserEmail { get; set; }
        [ForeignKey("UserEmail")]
        public User? User { get; set; }

        
    }
    
}